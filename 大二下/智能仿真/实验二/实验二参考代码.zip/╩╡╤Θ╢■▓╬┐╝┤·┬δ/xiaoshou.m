function varargout = xiaoshou(varargin)
% XIAOSHOU MATLAB code for xiaoshou.fig
%      XIAOSHOU, by itself, creates a new XIAOSHOU or raises the existing
%      singleton*.
%
%      H = XIAOSHOU returns the handle to a new XIAOSHOU or the handle to
%      the existing singleton*.
%
%      XIAOSHOU('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in XIAOSHOU.M with the given input arguments.
%
%      XIAOSHOU('Property','Value',...) creates a new XIAOSHOU or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before xiaoshou_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to xiaoshou_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help xiaoshou

% Last Modified by GUIDE v2.5 13-Nov-2021 15:22:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @xiaoshou_OpeningFcn, ...
                   'gui_OutputFcn',  @xiaoshou_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before xiaoshou is made visible.
function xiaoshou_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to xiaoshou (see VARARGIN)

% Choose default command line output for xiaoshou
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes xiaoshou wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = xiaoshou_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit_in_week_Callback(hObject, eventdata, handles)
% hObject    handle to edit_in_week (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.n=str2num(get(hObject,'string'));	%获取输入的周�?
%将对应的库存量显示输�?
set(handles.text14,'string',num2str(handles.I(handles.n))); 
guidata(hObject,handles);	%更新数据

% Hints: get(hObject,'String') returns contents of edit_in_week as text
%        str2double(get(hObject,'String')) returns contents of edit_in_week as a double


% --- Executes during object creation, after setting all properties.
function edit_in_week_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_in_week (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_compute.
function pushbutton_compute_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_compute (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
week=[1:1:10];			%week是周数，是画图时的x�?
for k=2:10
    handles.P(k)=handles.S(k-1);
end
for k=1:9
    handles.I(k+1)=handles.P(k)+handles.I(k)-handles.S(k);
end
plot(week,handles.I,'r-*',[1,10],[0,0],'m--','LineWidth',2);			%画图
grid on
xlim([1 10]);		%设置x轴显示范�?
legend('库存变化曲线');		%图例
xlabel('周数/�?');ylabel('库存中的手推车数�?/�?');	%标明x、y轴的含义
title('库存量对于周数k的变化曲线I(k)')

index=find(handles.I<=0);	%查找库存�?0的周�?

if ~isempty(index)	%如果index非空，将输出哪一周库存为0的信�?
    set(handles.text_p,'string',num2str(index(1)));
else		%index为空，则提示10周内不会出现库存�?0的情�?
    set(handles.text_p,'string','NULL')
end
set(handles.edit_in_week,'string','');
set(handles.text14,'string','');
set(handles.pushbutton_save,'string','保存表一数据');
max_S=max(handles.S);
set(handles.text17,'string',['初始库存和初始生产量之和�?',num2str(max_S)]);
guidata(hObject,handles);		%数据更新



% --- Executes on button press in pushbutton_save.
function pushbutton_save_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
q=handles.S;		%将其转为变量再保存到xs.mat文件�?
save('xs.mat','q');
set(handles.pushbutton_save,'string','保存成功');	%保存成功，输出提示信�?


% --- Executes on button press in pushbutton_cl.
function pushbutton_cl_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_cl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1);    %清除坐标轴区域的内容
cla reset;
%各编辑框、按钮都显示程序运行之前的默认�?�，以便用户再次拟合
set(handles.edit_in_i,'string','');
set(handles.edit_in_p,'string','');
set(handles.edit_in_s,'string','');
set(handles.edit_in_week,'string','');
set(handles.text14,'string','');
set(handles.text_p,'string','');
set(handles.pushbutton_save,'string','保存表一数据');
set(handles.text17,'string','');



function edit_in_i_Callback(hObject, eventdata, handles)
% hObject    handle to edit_in_i (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.I=zeros(10,1)';	%初始化存放生产量的矩�?
handles.I(1)=str2num(get(hObject,'string'));	%获取输入的初始库存量
guidata(hObject,handles); %数据更新


% Hints: get(hObject,'String') returns contents of edit_in_i as text
%        str2double(get(hObject,'String')) returns contents of edit_in_i as a double


% --- Executes during object creation, after setting all properties.
function edit_in_i_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_in_i (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_in_p_Callback(hObject, eventdata, handles)
% hObject    handle to edit_in_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.P=zeros(10,1)';	%初始化存放生产量的矩�?
handles.P(1)=str2num(get(hObject,'string'));	%获取输入的初始库存量
guidata(hObject,handles); %数据更新
% Hints: get(hObject,'String') returns contents of edit_in_p as text
%        str2double(get(hObject,'String')) returns contents of edit_in_p as a double


% --- Executes during object creation, after setting all properties.
function edit_in_p_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_in_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_in_s_Callback(hObject, eventdata, handles)
% hObject    handle to edit_in_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.S=str2num(get(hObject,'string'));	%获取输入的计划销售量的数�?
guidata(hObject,handles); %数据更新

% Hints: get(hObject,'String') returns contents of edit_in_s as text
%        str2double(get(hObject,'String')) returns contents of edit_in_s as a double


% --- Executes during object creation, after setting all properties.
function edit_in_s_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_in_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_in.
function pushbutton_in_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_in (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load xs.mat
handles.S=q;
set(handles.edit_in_s,'string',num2str(handles.S));
guidata(hObject,handles); %数据更新
