from sklearn.datasets import load_wine
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split

import pandas as pd
import matplotlib.pyplot as plt
data = load_wine()

data_x = data.data
data_y = data.target

xtrain,xtest,ytrain,ytest = train_test_split(data_x,data_y,test_size = 0.4 ,random_state = 1 )

# print(xtest.shape)

score = []
k = [3,5,7]
i = 0
for x in k:
    knn = KNeighborsClassifier(n_neighbors = x)

    clf = knn.fit(xtrain,ytrain)

    score.append(clf.score(xtest,ytest))
    i = i + 1


fig = plt.figure(alpha = 0.5)
plt.bar(k,score,color = 'r')

plt.xlabel = "k"
plt.ylabel = "ppp"

# plt.legend = "ss"
# fig.align_ylabels = "p"

plt.show()





# # clf.score
# print(s)
# # print(data_x)
# print(data_y)

# print(pd.DataFrame(data_x,columns = data.feature_names ))









