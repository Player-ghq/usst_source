package com.zlj.escales;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class MainActivity extends AppCompatActivity{

    Handler handler;
    Socket socket = null;
    OutputStream mOutputStream = null;
    InputStream mInputStream = null;
    String data_ = "";
    int len = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        TextView zl = findViewById(R.id.zl);

        Thread tt = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //int i = 0;
                    while (true){
                        byte[] buffer = new byte[100000];
                        if(socket != null) {
                            mInputStream = socket.getInputStream();
                            if (socket.isConnected()) {
                                if (!socket.isInputShutdown()) {
                                    len = mInputStream.read(buffer);
                                    data_ = new String(buffer, 0, len);
                                    handler.sendEmptyMessage(4);
                                    //i++;
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    handler.sendEmptyMessage(5);
                    Log.i("debug_running",Log.getStackTraceString(e));
                    e.printStackTrace();
                }
            }
        });

        handler = new Handler(Looper.myLooper()) {
            public void handleMessage(Message msg) {
                switch (msg.what){
                    case 0:
                        Toast.makeText(MainActivity.this, "Connect Success!", Toast.LENGTH_SHORT).show();
                        tt.start();
                        break;
                    case 1:
                        Toast.makeText(MainActivity.this, "Connect Filed", Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        Toast.makeText(MainActivity.this, "Connect ERR", Toast.LENGTH_SHORT).show();
                        break;
                    case 4:
                        zl.setText(data_);
                        Toast.makeText(MainActivity.this, "OK!", Toast.LENGTH_SHORT).show();
                        break;
                    case 5:
                        Toast.makeText(MainActivity.this, "fuck!", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        break;
                }
            }
        };

        Button connect = findViewById(R.id.connect);
        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            socket = new Socket("192.168.4.1", 2333);
                            if(socket.isConnected()){
                                mOutputStream = socket.getOutputStream();
                                mInputStream = socket.getInputStream();
                                mOutputStream.write("Connected\n".getBytes("utf-8"));
                                handler.sendEmptyMessage(0);
                            }
                            else{
                                handler.sendEmptyMessage(1);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                            Log.i("debug",Log.getStackTraceString(e));
                            handler.sendEmptyMessage(2);
                        }
                    }
                }).start();
            }
        });


    }
/*
    @Override
    public void run() {
        try {
            //int i = 0;
            while (true){
                byte[] buffer = new byte[100000];
                if(socket != null) {
                    mInputStream = socket.getInputStream();
                    if (socket.isConnected()) {
                        if (!socket.isInputShutdown()) {
                            len = mInputStream.read(buffer);
                            data_ = new String(buffer, 0, len);
                            handler.sendEmptyMessage(4);
                            //i++;
                        }
                    }
                }
            }
        } catch (Exception e) {
            handler.sendEmptyMessage(5);
            Log.i("debug_running",Log.getStackTraceString(e));
            e.printStackTrace();
        }
    }*/
}