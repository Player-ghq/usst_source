#include "IIC.h"
#include <intrins.h>

extern unsigned char i,j;

void IIC_Start(){
	SDA = 1;
	IIC_Delay(1);
	SCL = 1;
	IIC_Delay(1);
	SDA = 0;
	IIC_Delay(1);
	SCL = 0;
	IIC_Delay(1);
}

void IIC_Stop(){
	SDA = 0;
	IIC_Delay(1);
	SCL = 1;
	IIC_Delay(1);
	SDA = 1;
	IIC_Delay(11);
}

void IIC_Send(unsigned char _data){
	i, j = 0;
	for(i = 0; i < 8; i++){
		SDA = _data >> 7;
		_data <<= 1;
		IIC_Delay(1);
		SCL = 1;
		IIC_Delay(1);
		SCL = 0;
		IIC_Delay(1);
	}
	SCL = 0;
}

unsigned char IIC_Read(){
	unsigned char value = 0;
	i = 0;
	for(i = 0; i < 8 ; i++){
		value <<= 1;
		SCL = 1;
		value |= SDA;
		SCL = 0;
		IIC_Delay(1);
	}
	return value;
}

bit IIC_Read_ACK(){
	SCL = 1;
	if(SDA){
		SCL = 0;
		IIC_Stop();
		return 0;
	}
	else{
		SCL = 0;
		return 1;
	}
}

void IIC_Send_ACK(){
	SDA = 0;
	IIC_Delay(1);
	SCL = 1;
	IIC_Delay(1);
	SCL = 0;
	IIC_Delay(1);
	SDA = 1;
	IIC_Delay(1);
}

void IIC_Send_NACK(){
	SDA = 1;
	IIC_Delay(10);
	SCL = 1;
	IIC_Delay(10);
	SCL = 0;
	IIC_Delay(10);
}

void IIC_Delay(int i){
	_nop_();
	while(i--);
}
