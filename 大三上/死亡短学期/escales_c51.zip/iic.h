#ifndef __IIC_H__
#define __IIC_H__
#include "main.h"

sbit SDA = P2^6;
sbit SCL = P2^7;

void IIC_Start();
void IIC_Stop();
void IIC_Send(unsigned char _data);
unsigned char IIC_Read();
bit IIC_Read_ACK();
void IIC_Send_ACK();
void IIC_Send_NACK();
void IIC_Delay(int i);

#endif