#include "oled.h"
#include "main.h"

extern unsigned char i, j, k;

void OLED_WR_Byte(u8 dat, u8 cmd)
{	
	i = 0;			  
	if(cmd)
		OLED_DC = 1;
	else 
		OLED_DC = 0;		  
	OLED_CS = 0;
	for(i = 0; i < 8; i++)
	{
		OLED_SCL = 0;
		if(dat & 0x80)
		{
			OLED_SDI = 1;
		}
		else
			OLED_SDI = 0;
		OLED_SCL = 1;
		dat <<= 1;
	}
	OLED_CS = 1;
	OLED_DC = 1;
}

void OLED_Set_Pos(unsigned char x, unsigned char y)
{
	OLED_WR_Byte(0xB0 + y, 0);
	OLED_WR_Byte(((x & 0xF0) >> 4) | 0x10, 0);
	OLED_WR_Byte((x & 0x0F) | 0x01, 0);
}

void OLED_Display_On(void)
{
	OLED_WR_Byte(0X8D, 0);
	OLED_WR_Byte(0X14, 0);
	OLED_WR_Byte(0XAF, 0);
}

void OLED_Display_Off(void)
{
	OLED_WR_Byte(0X8D, 0);
	OLED_WR_Byte(0X10, 0);
	OLED_WR_Byte(0XAE, 0);
}

void OLED_Clear(void)  
{
	for(i = 0; i < 8; i++)
	{  
		OLED_WR_Byte (0xb0 + i, 0);
		OLED_WR_Byte (0x00, 0);
		OLED_WR_Byte (0x10, 0); 
		for(j = 0; j < 128; j++)OLED_WR_Byte(0, 1);
	}
}

void OLED_ShowChar(u8 x, u8 y, u8 chr, u8 s)
{      	
	u8 i = 0, k = chr - ' ';
	if(x > 127)
	{
		x = 0;
		y = y + 2;
	}
	if(s == 16){
		OLED_Set_Pos(x, y);	
		for(i = 0; i < 8; i++)
			OLED_WR_Byte(F8X16[k * 16 + i], 1);
		OLED_Set_Pos(x, y + 1);
		for(i = 0; i < 8; i++)
			OLED_WR_Byte(F8X16[k * 16 + i + 8], 1);
	}
	else{
		OLED_Set_Pos(x, y);
		for(i = 0; i < 6; i++)
			OLED_WR_Byte(F6x8[k][i], 1);
	}
}

void OLED_ShowString(u8 x, u8 y, u8 *chr, u8 s)
{
	j = 0;
	while(chr[j] != '\0')
	{
		OLED_ShowChar(x, y, chr[j], s);
		x += 8;
		if(x > 120)
		{
			x = 0;
			y += 2;
		}
		j++;
	}
}

void OLED_ShowCHinese(u8 x, u8 y, u8 no, u8 s)
{      			    
	u8 t,adder = 0;
	OLED_Set_Pos(x, y);
	if(s == 16){
		for(t = 0; t < 16; t++)
		{
			OLED_WR_Byte(chinese[2 * no][t], 1);
			adder += 1;
		}
		OLED_Set_Pos(x, y + 1);	
		for(t = 0; t < 16; t++)
		{
			OLED_WR_Byte(chinese[2 * no + 1][t], 1);
			adder += 1;
		}
	}
	if(s == 12){
		for(t = 0; t < 12; t++)
		{
			OLED_WR_Byte(chinese12[2 * no][t], 1);
			adder += 1;
		}
		OLED_Set_Pos(x, y + 1);	
		for(t = 0; t < 12; t++)
		{
			OLED_WR_Byte(chinese12[2 * no + 1][t], 1);
			adder += 1;
		}
	}
}

void OLED_Init(void)
{
  OLED_RST = 1;
	DelayMS(100);
	OLED_RST = 0;
	DelayMS(100);
	OLED_RST = 1;

	OLED_WR_Byte(0xAE, 0);//--turn off oled panel
	OLED_WR_Byte(0x00, 0);//---set low column address
	OLED_WR_Byte(0x10, 0);//---set high column address
	OLED_WR_Byte(0x40, 0);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
	OLED_WR_Byte(0x81, 0);//--set contrast control register
	OLED_WR_Byte(0xCF, 0); // Set SEG Output Current Brightness
	OLED_WR_Byte(0xA1, 0);//--Set SEG/Column Mapping     0xa0左右反置 0xa1正常
	OLED_WR_Byte(0xC8, 0);//Set COM/Row Scan Direction   0xc0上下反置 0xc8正常
	OLED_WR_Byte(0xA6, 0);//--set normal display
	OLED_WR_Byte(0xA8, 0);//--set multiplex ratio(1 to 64)
	OLED_WR_Byte(0x3f, 0);//--1/64 duty
	OLED_WR_Byte(0xD3, 0);//-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
	OLED_WR_Byte(0x00, 0);//-not offset
	OLED_WR_Byte(0xd5, 0);//--set display clock divide ratio/oscillator frequency
	OLED_WR_Byte(0x80, 0);//--set divide ratio, Set Clock as 100 Frames/Sec
	OLED_WR_Byte(0xD9, 0);//--set pre-charge period
	OLED_WR_Byte(0xF1, 0);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
	OLED_WR_Byte(0xDA, 0);//--set com pins hardware configuration
	OLED_WR_Byte(0x12, 0);
	OLED_WR_Byte(0xDB, 0);//--set vcomh
	OLED_WR_Byte(0x40, 0);//Set VCOM Deselect Level
	OLED_WR_Byte(0x20, 0);//-Set Page Addressing Mode (0x00/0x01/0x02)
	OLED_WR_Byte(0x02, 0);//
	OLED_WR_Byte(0x8D, 0);//--set Charge Pump enable/disable
	OLED_WR_Byte(0x14, 0);//--set(0x10) disable
	OLED_WR_Byte(0xA4, 0);// Disable Entire Display On (0xa4/0xa5)
	OLED_WR_Byte(0xA6, 0);// Disable Inverse Display On (0xa6/a7) 
	OLED_WR_Byte(0xAF, 0);//--turn on oled panel

	OLED_WR_Byte(0xAF, 0); /*display ON*/ 
	OLED_Clear();
	OLED_Set_Pos(0,0);
}
