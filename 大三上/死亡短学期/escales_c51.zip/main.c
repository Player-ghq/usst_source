#include "main.h"
#include "iic.h"
#include "oled.h"
#include "stdio.h"
#include "uart.h"
#include <intrins.h>
#define FOSC 11059200L      //System frequency
#define BAUD 9600           //UART baudrate

unsigned char i, j;
unsigned long kg_r = 1030927835;
extern unsigned char g;
unsigned char code danwei1[] = "KG", danwei2[] = "G`";
extern bit key1, key2;
bit reend = 0;
u8 gg[15], dw = 0;
float jg = 1.234, zl = 0.0, rd = 0.0, zl_old = 0.0;

int main()
{
	init_c51();
	OLED_Init();
	OLED_Clear();
	Write_MCP3421(0x9c);
	DelayMS(10);
	OLED_ShowString(0, 0, "E-SCALES", 8);
	/*����*/
	OLED_ShowCHinese(0, 2, 4, 12);
	OLED_ShowCHinese(12, 2, 5, 12);
	OLED_ShowCHinese(24, 2, 3, 12);
	/*��λ*/
	OLED_ShowCHinese(80, 0, 0, 12);
	OLED_ShowCHinese(92, 0, 2, 12);
	OLED_ShowCHinese(104, 0, 3, 12);
	OLED_ShowString(110, 0, "KG", 16);
	/*����*/
	OLED_ShowCHinese(0, 4, 0, 12);
	OLED_ShowCHinese(12, 4, 1, 12);
	OLED_ShowCHinese(24, 4, 3, 12);
	//OLED_ShowString(30, 4, "12.34", 16);
	/*zong��*/
	OLED_ShowCHinese(0, 6, 4, 12);
	OLED_ShowCHinese(12, 6, 1, 12);
	OLED_ShowCHinese(24, 6, 3, 12);
	//OLED_ShowString(30, 6, "10.21", 16);
	OLED_ShowCHinese(110, 6, 0, 16);
	while(1){
		if(g > 2){
			rd = READ_MCP3421();
			zl = (float)rd*kg_r/1000000 - zl_old;
			sprintf(gg, "%7.5f", jg);
			OLED_ShowString(30, 4, gg, 16);
			sprintf(gg, "%7.5f", jg * zl / 1000);
			OLED_ShowString(30, 6, gg, 16);
			if(dw == 0)
				sprintf(gg, "%7.5f", zl/1000);
			else sprintf(gg, "%7.5f", zl);
			OLED_ShowString(30, 2, gg, 16);
			sprintf(gg, "%7.5f\r\n", zl);
			SendString(gg);
			g = 0;
		}
		if(key1){
			//SendString("key1\r\n");
			if(dw == 0){
				dw = 1;
				OLED_ShowString(110, 0, danwei2, 16);
			}
			else if(dw == 1){
				dw = 0;
				OLED_ShowString(110, 0, danwei1, 16);
			}
			//SendString(gg);
			//SendString(rec);
			key1 = 0;
		}
		if(key2){
			//SendString("key2\r\n");
			zl_old = (float)rd*kg_r/1000000;
			key2 = 0;
		}
		//DelayMS(100);
	}
	return 0;
}

void init_c51(){
	SCON = 0x50;            //8-bit variable UART
	TMOD = 0x21;//��ʱ��ģʽ1
	TH0 = 0xDC;
	TL0 = 0x00;
	TR0 = 1;//��ʱ��1����
	ET0 = 1;//�򿪶�ʱ��1�ж�
	
	TH1 = TL1 = -(FOSC/12/32/BAUD); //Set auto-reload vaule
	TR1 = 1;                //Timer1 start run
	ES = 1;                 //Enable UART interrupt
	EA = 1;                 //Open master interrupt switch
	
	EX0 = 1;//�ⲿ�ж�0
	EX1 = 1;//�ⲿ�ж�1
	IT0 = 0;//0�����ش���
	IT1 = 0;//1�����ش���
	
	EA = 1;//��ȫ���ж�
	
}

void Delay1ms()		//@11.0592MHz
{
	_nop_();
	_nop_();
	_nop_();
	i = 11;
	j = 190;
	do
	{
		while(--j);
	}
	while(--i);
}

void DelayMS(unsigned int a){
	while(a--)
		Delay1ms();
}