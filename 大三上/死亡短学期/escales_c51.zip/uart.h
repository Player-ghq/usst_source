#ifndef __UART_H__
#define __UART_H__
#include "main.h"

void SendData(BYTE dat);
void SendString(char *s);

#endif