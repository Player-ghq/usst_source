#include "mcp3421.h"

void Write_MCP3421(unsigned char WR_Data)
{
  IIC_Start();
  IIC_Send(0xd0);
  IIC_Read_ACK();
  IIC_Send(WR_Data);      
  IIC_Read_ACK();
  IIC_Stop();
}

float READ_MCP3421()
{
	unsigned long int elech;
	unsigned long int AD_B_Result;
	float AD_F_Result=0.0;
	IIC_Start();
	IIC_Send(0xd1);
	IIC_Read_ACK();
	elech=(unsigned long)IIC_Read();
	AD_B_Result=(elech<<16);
	IIC_Send_ACK();
	elech=(unsigned long)IIC_Read();
	AD_B_Result=AD_B_Result|(elech<<8);
	IIC_Send_ACK();
	elech=(unsigned long)IIC_Read();
	AD_B_Result=AD_B_Result|(elech);
	IIC_Send_ACK();
	elech = (unsigned long)IIC_Read();
	IIC_Send_NACK();
	IIC_Stop();
	AD_B_Result=AD_B_Result&0x01ffffff;
	AD_F_Result = (float)((float)(2.0 * 2.048) / 262144 * AD_B_Result);
	return AD_F_Result;
}