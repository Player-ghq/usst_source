#ifndef __MAIN_H__
#define __MAIN_H__
#include "89c51.h"
#include "mcp3421.h"
#include "string.h"

typedef unsigned long u32;
typedef unsigned int u16;
typedef unsigned char u8;
typedef unsigned char BYTE;
typedef unsigned int WORD;

extern unsigned long kg_r;

void DelayMS(unsigned int a);
void init_c51();
void SendData(BYTE dat);
void SendString(char *s);

#endif